#!/usr/bin/env bash
cmd="backup $1"
source scripts/_lib.sh
$cmd
